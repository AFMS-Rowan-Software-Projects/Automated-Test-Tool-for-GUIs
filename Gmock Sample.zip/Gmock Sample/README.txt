This sample program has a makefile which helps with compiling
the file, any changes made to the c++ file can be compiled
by runining the make command. The make file also has make clean
option which removes all the object files.
