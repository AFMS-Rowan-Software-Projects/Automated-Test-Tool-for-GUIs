
#include <stdio.h>


#ifndef __XDEV_H
#define __XDEV_H

#ifdef __cplusplus
extern "C" {
#endif

int xdev_get_link_status(int port);

#ifdef __cplusplus
}
#endif

#endif /* __XDEV_H */

