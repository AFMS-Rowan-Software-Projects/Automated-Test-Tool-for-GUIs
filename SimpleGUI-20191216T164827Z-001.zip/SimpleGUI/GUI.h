#ifndef GUI_H
#define GUI_H

#include "GUI.h"
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include <iostream>

using namespace std;

class GUI
{
    public:
        GUI(int argc, char *argv[]);
        virtual ~GUI();

    protected:

    private:

        //Callback functions for each type of widget to be tested.
        //For each, a static "wrapper" function provided to
        //interface with Motif XtAddCallback function.
        //Wrapper calls subsequent function to provide callback
        //functionality.
        static void pushbutton_callback (Widget widget, XtPointer client_data, XtPointer call_data);
        void pushbutton_pushed (Widget widget, XtPointer client_data, XtPointer call_data);
};

#endif // GUI_H
