Simple pushbutton GUI written in C++ and using Motif API. Use included makefile to compile.
