#include <iostream>
#include "GUI.h"

using namespace std;

int main(int argc, char *argv[])
{

    GUI myGUI (argc, argv);

    return 0;
}
