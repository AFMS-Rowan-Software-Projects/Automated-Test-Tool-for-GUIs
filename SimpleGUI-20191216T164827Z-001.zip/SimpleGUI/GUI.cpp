#include "GUI.h"
#include "GUI.h"
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include "GUI.h"
#include <iostream>

using namespace std;

GUI::GUI(int argc, char *argv[])
{


    Widget        toplevel, rowColumn, pushButton;

    XtAppContext  app;

    XmString      label1;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "GUI Test", NULL, 0,
                                  &argc, argv, NULL, NULL);

    rowColumn = XtCreateManagedWidget ("rowcolumn", xmRowColumnWidgetClass,
                                       toplevel, NULL, 0);

    //Set up pushbutton
    label1 = XmStringCreateLocalized ("Pushbutton");
    pushButton = XtVaCreateManagedWidget ("Pushbutton", xmPushButtonWidgetClass,
                                        rowColumn, NULL, 0);
    XmStringFree (label1);
    XtAddCallback (pushButton, XmNactivateCallback,
                   &GUI::pushbutton_callback, (XtPointer) this);


    //Display GUI
    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
}

GUI::~GUI()
{
    //dtor
}


//Static callback function (has no leading "this" pointer, thus
//compatible with Motif
void GUI::pushbutton_callback(Widget widget, XtPointer client_data, XtPointer call_data)
{
    //Create pointer to callback
    GUI *obj = (GUI*) client_data;

    //Assign callback pointer to C++ function
    obj -> pushbutton_pushed(widget, client_data, call_data);

}//End of pushbutton_callback

//Piggyback callback when pushbutton button pressed
void GUI::pushbutton_pushed(Widget widget, XtPointer client_data, XtPointer call_data)
{
    cout << "button worked" << endl;
}
