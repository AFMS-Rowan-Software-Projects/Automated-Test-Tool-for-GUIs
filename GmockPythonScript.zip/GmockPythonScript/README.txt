You can use this python script to mock some header files
./gmock_gen.py turtle.h > mock_turtle.h
Sometimes you need to be root to run the command here
is the command for that case.
sudo ./gmock_gen.py turtle.h > mock_turtle.h
