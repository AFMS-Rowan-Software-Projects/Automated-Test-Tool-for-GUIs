#include "MouseEvent.h"
#include <string>

using namespace std;

//Constructor
MouseEvent::MouseEvent()
{
    MouseEvent::event.eventType = 0;
    MouseEvent::event.buttonPressed = "nopress";
    MouseEvent::event.x = 0;
    MouseEvent::event.y = 0;
    MouseEvent::event.buttonReleased = "norelease";
}

//Destructor
MouseEvent::~MouseEvent()
{
    //dtor
}

//Set mouse button pressed
void MouseEvent::set_press(string buttonPressed)
{
    MouseEvent::event.buttonPressed = buttonPressed;
}

//Get mouse press
string MouseEvent::get_press()
{
    return event.buttonPressed;
}

//Set mouse button released
void MouseEvent::set_release(string buttonReleased)
{
    MouseEvent::event.buttonReleased = buttonReleased;
}

//Get mouse release
string MouseEvent::get_release()
{
    return event.buttonReleased;
}

//Set coordinates of mouse event
void MouseEvent::set_coord(int x, int y)
{
    MouseEvent::event.x = x;
    MouseEvent::event.y = y;
}

//Get mouse x-coord
int MouseEvent::get_x()
{
    return event.x;
}

//Get mouse y-coord
int MouseEvent::get_y()
{
    return event.y;
}

//Convert mouse event to string data
string MouseEvent::to_string()
{
    string outString = MouseEvent::event.buttonPressed + "\n" +
                       std::to_string (MouseEvent::event.x)+ "\n" +
                       std::to_string (MouseEvent::event.y) + "\n" +
                       MouseEvent::event.buttonReleased;
    return outString;
}
