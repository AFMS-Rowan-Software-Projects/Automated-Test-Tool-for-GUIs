#ifndef TRACKER_H
#define TRACKER_H


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> //in order to use getopt()

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysymdef.h>
#include <X11/keysym.h>
#include <X11/extensions/record.h>

#include <iostream> //.h if needed
#include <ostream>
#include <iomanip> //.h if needed
#include <string>
#include "MouseEvent.h"

using namespace std;

class Tracker
{
    public:
        Tracker();
        virtual ~Tracker();

        void track_mouse();
        static constexpr int DefaultDelay = 10;
        static constexpr float DefaultScale = 1.0;
        string get_button_pressed();
        string get_button_released();
        int get_x();
        int get_y();




    private:

        bool HasQuitKey; //whether or not quit key was assigned
        unsigned int QuitKey; //this is unsigned because we are going to ask the user
                          // what key they will be using

        static Display *localDisplay();
        static int findQuitKey (Display *Dpy, int Screen);
        void eventLoop (Display *LocalDpy, int LocalScreen,
                               Display *RecDpy, unsigned int QuitKey);
        static int scale (const int Coordinate);
        void eventCallback(XPointer priv, XRecordInterceptData *d);
        static void callback (XPointer priv, XRecordInterceptData *d);

        // create an alias for data type that can't be overwritten by a function
        typedef struct
        {
        int Status1,
            Status2,
            x,
            y,
            mmoved,
            doit;
        unsigned int QuitKey;
        Display *LocalDpy, *RecDpy;
        XRecordContext rc;

        } Priv;//End of struct

        MouseEvent event;

};

#endif // TRACKER_H
