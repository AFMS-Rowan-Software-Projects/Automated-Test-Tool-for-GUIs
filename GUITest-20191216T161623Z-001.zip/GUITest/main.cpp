//GUI Test
//Version 1.0
//Authors: Jennifer AñoNuevo, Robert Dumitrescu, George Clelland,
//         Donald Zellman, Julio Crespo, Shubham Patel

//GUI Test allows automated testing of GUIs by exporting mouse
//events to XML file for import into Google Test w/Google Mock.

//This program is open source. You are free to use/modify it under the terms of
//the GNU General Public License as published by the Free Software Foundation.

#include "GUI.h"
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include "GUITestController.h"
#include <iostream>
#include "GUI.h"
#include "Tracker.h"

using namespace std;


//Instantiates GUI and controller. All other functions
//initiated or called by GUI and controller classes.
int main(int argc, char *argv[])
{


    static GUITestController controller;
    //Create GUI
    static GUI testGUI (controller, argc, argv);


    return 0;

}//End of main



