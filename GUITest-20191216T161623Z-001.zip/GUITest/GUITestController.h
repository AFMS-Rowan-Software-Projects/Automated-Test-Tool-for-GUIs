#ifndef GUITESTCONTROLLER_H
#define GUITESTCONTROLLER_H

#include "EventRepository.h"
#include "Tracker.h"

using namespace std;

//Class GUITestController provides controller functionality to GUI Test
class GUITestController
{
    public:

        //Constructor
        GUITestController();
        //GUITestController(Tracker &mouseTracker);

        //Destructor
        virtual ~GUITestController();

        void record(int count);

        //Getters/setters
        int size_of_repo();
        //Inform controller of type of
        //mouse event to record
        void set_event_type(int eventType);


    protected:

    private:
        EventRepository repository;
        int recordEventType;

        void add(MouseEvent event);


        MouseEvent event;
        Tracker mouseTracker;



};

#endif // GUITESTCONTROLLER_H
