#include "GUI.h"
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include "GUITestController.h"
#include <iostream>

using namespace std;


//Class GUI builds basic GUI interface with callbacks
//to controller functions through static wrapper interfaces.
//Uses controller passed through constructor to perform
//all external functions.


//Constructor
//Builds GUI and assigns callbacks.
GUI::GUI(GUITestController &controller, int argc, char* argv[])
{

    Widget        toplevel, rowColumn, pushButton, scrollboxButton, textboxButton,
                          button4, button5;
    Widget        button6, button7, button8, buttonSave,
                          textXLabel, textX, textYLabel, textY;
    XtAppContext  app;

    XmString      label1;

    XtSetLanguageProc (NULL, NULL, NULL);

    toplevel = XtVaAppInitialize (&app, "GUI Test", NULL, 0,
                                  &argc, argv, NULL, NULL);

    rowColumn = XtCreateManagedWidget ("rowcolumn", xmRowColumnWidgetClass,
                                       toplevel, NULL, 0);

    //Set up pushbutton
    //label1 = XmStringCreateLocalized ("Pushbutton");
    pushButton = XtVaCreateManagedWidget ("Pushbutton", xmPushButtonWidgetClass,
                                        rowColumn, NULL, 0);
    //XmStringFree (label1);
    XtAddCallback (pushButton, XmNactivateCallback,
                   &GUI::pushbutton_callback, (XtPointer) this);


    //Set up scrollbox button
    scrollboxButton = XtVaCreateManagedWidget ("Scrollbox", xmPushButtonWidgetClass,
                                                rowColumn, NULL, 0);
    XtAddCallback (scrollboxButton, XmNactivateCallback,
                   &GUI::scrollbox_callback, (XtPointer) this);

    //Set up button textbox button
    textboxButton = XtVaCreateManagedWidget ("Textbox", xmPushButtonWidgetClass,
                                       rowColumn, NULL, 0);
    XtAddCallback (textboxButton, XmNactivateCallback,
                   &GUI::textbox_callback, (XtPointer) this);


    //XXXXXX Functionality for widgets below not yet implemented XXXXXXX

    //Set up button 5
    button5 = XtVaCreateManagedWidget ("DropBox", xmPushButtonWidgetClass,
                                       rowColumn, NULL, 0);
    //XtAddCallback (button5, XmNactivateCallback, button1_pushed, NULL);

    //Set up button 6
    button6 = XtVaCreateManagedWidget ("RadioButton", xmPushButtonWidgetClass,
                                       rowColumn, NULL, 0);
    //XtAddCallback (button6, XmNactivateCallback, button1_pushed, NULL);

    //Set up button 7
    button7 = XtVaCreateManagedWidget ("Start Recording", xmPushButtonWidgetClass,
                                       rowColumn, NULL, 0);
    //XtAddCallback (button7, XmNactivateCallback, button1_pushed, NULL);

    //Set up button8
    button8 = XtVaCreateManagedWidget ("Save session to XML", xmPushButtonWidgetClass,
                                       rowColumn, NULL, 0);
    //XtAddCallback (button8, XmNactivateCallback, button1_pushed, NULL);

    //Display x test resolution text box label
    textXLabel = XtVaCreateManagedWidget ("Test X Resolution", xmLabelWidgetClass,
                                          rowColumn, NULL);

    //Display x test resolution text box
    textX = XtVaCreateManagedWidget("name", xmTextWidgetClass, rowColumn,
                                    XmNvalue, "", NULL);

    //Display y test resolution text box label
    textYLabel = XtVaCreateManagedWidget ("Test Y Resolution", xmLabelWidgetClass,
                                          rowColumn, NULL);

    //Display y test resolution text box
    textY = XtVaCreateManagedWidget("name", xmTextWidgetClass, rowColumn,
                                    XmNvalue, "", NULL);

    //Display GUI
    XtRealizeWidget (toplevel);
    XtAppMainLoop (app);
};//End of constructor


//Destructor
GUI::~GUI()
{
    //dtor

}//End of destructor


//Static callback function (has no leading "this" pointer, thus
//compatible with Motif
void GUI::pushbutton_callback(Widget widget, XtPointer client_data, XtPointer call_data)
{
    //Create pointer to callback
    GUI *obj = (GUI*) client_data;

    //Assign callback pointer to C++ function
    obj -> pushbutton_pushed(widget, client_data, call_data);

}//End of pushbutton_callback


//Piggyback callback when pushbutton button pressed
void GUI::pushbutton_pushed(Widget widget, XtPointer client_data, XtPointer call_data)
{
    static int count = 0; //Number of button pushes
    int selection = GUI::PUSHBUTTON; //Which button was pushed

    //If recording is off, turn on recording and change
    //color of widget. If already recording this widget,
    //return to non-recording color. Otherwise ignore request.
    if (recordMode == NONE)
    {
        //Number of relevant mouse clicks on this event
        //(do no increment if nother event is already recording).
        count++;

        recordMode = selection;
        set_widget_color(widget, count);

        cout << endl << "Pushbutton recording..." << endl;
        cout << "record mode" << recordMode << endl;

                //Add event
        controller.set_event_type(selection);

        //Test code onlyXXXXXXXXXXXXX need to add mouseevent from tracker
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

        controller.record(count);
    }
    else if (recordMode == selection)
    {
        //Number of relevant mouse clicks on this event
        //(do no increment another if event is already recording).
        count++;

        recordMode = NONE;
        set_widget_color(widget, count);

        //Stop recorder
        controller.record(count);


    }//End of else/if

}//End of pushbutton_pushed


//Static callback function (has no leading "this" pointer, thus
//compatible with Motif
void GUI::scrollbox_callback(Widget widget, XtPointer client_data, XtPointer call_data)
{
    //Create pointer to callback
    GUI *obj = (GUI*) client_data;

    //Assign callback pointer to C++ function
    obj -> scrollbox_pushed(widget, client_data, call_data);

}//End of scrollbox_callback


//Piggyback callback when scrollbox button pressed
void GUI::scrollbox_pushed(Widget widget, XtPointer client_data, XtPointer call_data)
{
    static int count = 0;
    int selection = SCROLLBOX;

    //If recording is off, turn on recording and change
    //color of widget. If already recording this widget,
    //return to non-recording color. Otherwise ignore request.
    if (recordMode == NONE)
    {
        //Number of relevant mouse clicks on this event
        //(do no increment if another event is already recording).
        count++;

        recordMode = selection;
        set_widget_color(widget, count);

        cout << endl << "Scrollbox recording..." << endl;
        cout << "record mode" << recordMode << endl;
    }
    else if (recordMode == selection)
    {
        //Number of relevant mouse clicks on this event
        //(do no increment if another event is already recording).
        count++;

        recordMode = NONE;
        set_widget_color(widget, count);

        //Add event
        controller.set_event_type(selection);
        //controller.add(testEvent);
    }//End of else/if

}//End of scrollbox_pushed

//Static callback function (has no leading "this" pointer, thus
//compatible with Motif
void GUI::textbox_callback(Widget widget, XtPointer client_data, XtPointer call_data)
{
    GUI *obj = (GUI*) client_data;

    obj -> textbox_pushed(widget, client_data, call_data);
}//End of textbox_callback

//Piggyback callback when textbox button pressed
void GUI::textbox_pushed(Widget widget, XtPointer client_data, XtPointer call_data)
{
    static int count = 0;
    int selection = TEXTBOX;

    cout << endl << "Textbox recording..." << endl;

    //increment count
    count++;
    //Add event
    controller.set_event_type(selection);
    //controller.add(count);


}//End of textbox_pushed


//Set widget color
void GUI::set_widget_color (Widget widget, int count)
{

    XColor color [1]; //Array of Pixels (unsigned long int):
                      //[0] stores default color,
                      //[1] stores recording color.

    Pixel backGround; //Color used to set widget scheme

    static Colormap cmap = DefaultColormap(XtDisplay(widget),
                    DefaultScreen(XtDisplay(widget)));; //Colormap for these widgets


    //Get original widget color (non-recording color)
    //This stub uses estimated Motif default gray; need to
    //augment to record actual widget original color.
    color [0].red = 50000;
    color [0].green = 50000;
    color [0].blue = 50000;
    color [0].flags = DoRed | DoGreen | DoBlue;


    //Set recording widget color
    color [1].red = 65535;
    color [1].green = 0;
    color [1].blue = 0;
    color [1].flags = DoRed | DoGreen | DoBlue;


    //Takes XColor.red, XColor.green, and Xcolor.blue fields
    //of XColor struct and updates XColor[].pixel field to
    //unsigned int representing RGB color combo
    XAllocColor (XtDisplay (widget), cmap, &color [0]);
    XAllocColor (XtDisplay (widget), cmap, &color [1]);


    //Select color based on record or ~record click
    backGround = color [count % 2].pixel;

    //Change color of widget
    XmChangeColor (widget, backGround);

}//End of set_widget_color
