/**************************************************************************
File: xAutorec
Portions Copyright (C) 2019 Jennifer Anonuevo <anonuevo.jenniferkat@gmail.com>
Programmer(s): Jennifer Anonuevo, George Clelland
Team: Fire Ants
Department of Computer Science, Rowan University
SWENG Fall 2019

Description: Records user mouse movement

This program is open source. You are free to use/modify it under the terms of
the GNU General Public License as published by the Free Software Foundation.

DISCLAIMER:

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.

CREDIT:

This program is heavily based on:

xremote (http://infa.abo.fi/~chakie/xremote/)
which is: Copyright (C) 2000 Jan Ekholm <chakie@infa.abo.fi>

xmacrorec2
which is: Portions Copyright (C) 2000 Gabor Keresztfalvi <keresztg@mail.com>
**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> //in order to use getopt()
#include <X11/Xlibint.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#include <X11/keysymdef.h>
#include <X11/keysym.h>
#include <X11/extensions/record.h>
#include <iostream> //.h if needed
#include <iomanip> //.h if needed
#include "Tracker.h"
#include "MouseEvent.h"
#include <string>

using namespace std;

#define PROGNAME "xAutoRec"
#define VERSION "1.0"


Tracker::Tracker()
{

}
/*
//Constructor
Tracker::Tracker(MouseEvent mouseEvent)
{
    event = mouseEvent;
}*/

//Destructor
Tracker::~Tracker()
{
    //dtor
}

string Tracker::get_button_pressed()
{
    return event.get_press();
}

string Tracker::get_button_released()
{
    return event.get_release();
}

int Tracker::get_x()
{
    return event.get_x();
}

int Tracker::get_y()
{
    return event.get_y();
}

void Tracker::track_mouse()
{
    int Major, Minor;

    //open the local display and get screens
    Display *LocalDpy = localDisplay ();
    Display *RecDpy = localDisplay ();

    int LocalScreen = DefaultScreen (LocalDpy);

    cerr << "Server VendorRelease: " << VendorRelease(RecDpy) << endl;

    //does the remote display havve the Xrecord-extension?
    if (! XRecordQueryVersion (RecDpy, &Major, &Minor))
    {
        cerr << PROGNAME << ": XRecord Extension not supported on server\""
        << DisplayString(RecDpy) << "\"" << endl;
        //close DISPLAY
        XCloseDisplay(RecDpy);
        exit (EXIT_FAILURE);
    }


    //Check for a quit key; if none, ask for it
    if(!HasQuitKey)
    {
      QuitKey = findQuitKey (LocalDpy, LocalScreen);
    }

    else
    {
      cerr << "The quit key is: " << QuitKey << endl;
    }

    // start the main event loop
     eventLoop ( LocalDpy, LocalScreen, RecDpy, QuitKey);

    // we're done with the display
    //  XCloseDisplay ( RecDpy );
    XCloseDisplay (LocalDpy);


    //TroubleshootingXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
    //This is zero'd out also (just after event loop exit)
        cout << "just before track_mouse exit..." << endl
            << "event.x = " << event.get_x()
            << " event.y = " << event.get_y() << endl;


}//End of track_mouse





    /**************************************************************************
                                CONNECT TO LOCAL DISPLAY
                            =================================
    returns the \c DISPLAY if can be obtained
    otherwise, resturns \c 0
    **************************************************************************/
    Display* Tracker::localDisplay()
    {
      // open display
      // note: The XOpenDisplay() function returns a Display structure that serves
      //       as the connection to the X server and that contains all the
      //       information about that X server
      Display *D = XOpenDisplay(0);

      if (!D)
      {
        cerr << PROGNAME << " could not open dislay \""
        << XDisplayName(0) << "\", aborting." << endl;
        exit (EXIT_FAILURE);
      }

      cerr << "Success in opening display" << endl;

      // if success, return the display
      return D;

    }//End of localDisplay

    /**************************************************************************
                                  ASSIGNING QUIT KEY
                              ==========================
    finds out the key user wants to use for quitting the application
    we are letting the user pick it because it cannot be determined in advance as
    it depends on keys the specific user know will not be used for any otherwise
    purpose

    \arg Display *Dpy = the used display
    \arg int Screen = the used screen
    **************************************************************************/
    int Tracker::findQuitKey (Display * Dpy, int Screen)
    {

      XEvent    Event;
      XKeyEvent EventKey;
      Window    Target, Root;
      bool      Loop = true;
      int       Error;

      // get the root window and set default target
      Root   = RootWindow ( Dpy, Screen );
      Target = None;

      // grab the keyboard
      Error = XGrabKeyboard ( Dpy, Root, False, GrabModeSync, GrabModeAsync, CurrentTime );

      // did we succeed in grabbing the keyboard?
      if ( Error != GrabSuccess)
      {
        cerr << "Could not grab the keyboard, aborting." << endl;
        exit ( EXIT_FAILURE );
      }

      // print a message to the user informing about what's going on
      cerr << endl
           << "Press the key you want to use to end the application. "
           << "This key can be any key, " << endl
           << "as long as you don't need it while working with the remote display."
         << endl << "A good choice is Escape." << endl << endl;

      // let the user select a window...
      while ( Loop )
      {
        // allow one more event
        XAllowEvents ( Dpy, SyncPointer, CurrentTime);
        XWindowEvent ( Dpy, Root, KeyPressMask, &Event);

        // what did we get?
        if ( Event.type == KeyPress )
        {
          // a key was pressed, don't loop more
          EventKey = Event.xkey;
          Loop = false;
          }
      }

      // we're done with pointer and keyboard
      XUngrabPointer  ( Dpy, CurrentTime );
      XUngrabKeyboard ( Dpy, CurrentTime );

      // show the user what was chosen
      cerr << "The chosen quit-key has the keycode: " << EventKey.keycode << endl;

      // return the found key
      return EventKey.keycode;

    }//End of findQuitKey



    /**************************************************************************
                                    EVENT CALLBACK
                                ======================
    Based on the xRemote code
    **************************************************************************/

    void Tracker::eventCallback(XPointer priv, XRecordInterceptData *d)
    {
        Priv *p=(Priv *) priv;
        unsigned int *ud4, tstamp, wroot, wevent, wchild, type, detail;
        unsigned char *ud1, type1, detail1, samescreen;
        unsigned short *ud2, seq;
        short *d2, rootx, rooty, eventx, eventy, kstate;

        if (d->category==XRecordStartOfData) cerr << "Got Start Of Data" << endl;
        if (d->category==XRecordEndOfData) cerr << "Got End Of Data" << endl;
        if (d->category!=XRecordFromServer || p->doit==0)
        {
        cerr << "Skipping..." << endl;
        goto returning;
        }

        if (d->client_swapped==True) cerr << "Client is swapped!!!" << endl;
        ud1=(unsigned char *)d->data;
        ud2=(unsigned short *)d->data;
        d2=(short *)d->data;
        ud4=(unsigned int *)d->data;

        type1=ud1[0]&0x7F; type=type1;
        detail1=ud1[1]; detail=detail1;
        seq=ud2[1];
        tstamp=ud4[1];
        wroot=ud4[2];
        wevent=ud4[3];
        wchild=ud4[4];
        rootx=d2[10];
        rooty=d2[11];
        eventx=d2[12];
        eventy=d2[13];
        kstate=d2[14];
        samescreen=ud1[30];

        if (p->Status1)
        {
            p->Status1--;
            if (type==KeyRelease)
            {
                cerr << "- Skipping stale KeyRelease event. " << p->Status1 << endl;
                goto returning;
            }
            else p->Status1=0;

        }//End of if

        if (p->x==-1 && p->y==-1 && p->mmoved==0 && type!=MotionNotify)
        {
            cerr << "- Please move the mouse before any other event to synchronize pointer" << endl;
            cerr << "  coordinates! This event is now ignored!" << endl;

            goto returning;

        }//End of if

        // what did we get?
        switch (type)
        {
            case ButtonPress:
                // button pressed, create event
                if (p->mmoved)
                {
                    cout << "MotionNotify " << p->x << " " << p->y << endl;
                    p->mmoved=0;
                }

                if (p->Status2<0) p->Status2=0;
                p->Status2++;
                cout << "ButtonPress " << detail << endl;


                break;

            case ButtonRelease:
                // button released, create event
                if (p->mmoved)
                {
                    cout << "MotionNotify " << p->x << " " << p->y << endl;
                    p->mmoved=0;
                }

                p->Status2--;
                if (p->Status2<0) p->Status2=0;
                cout << "ButtonRelease " << detail << endl;

                //Trying to store mouse data in eventXXXXXXXXXXXXXXXXXXXXXXXXX
                //Field is updating, but controller not able to access field data (all 0s)
                //  after exiting this tracker method.
                event.set_coord(p->x, p->y);

                cout << "from within tracker..." << endl
                     << "event.x = " << event.get_x()
                     << " event.y = " << event.get_y() << endl;

                break;

            case MotionNotify:
                // motion-event, create event
                if (p->Status2>0)
                {
                    cout << "MotionNotify " << rootx << " " << rooty << endl;
                    p->mmoved=0;
                }
                else p->mmoved=1;
                p->x=rootx;
                p->y=rooty;

                break;

            case KeyPress:
                // a key was pressed
                // should we stop looping, i.e. did the user press the quitkey?
                if ( detail == p->QuitKey )
                {
                    // yep, no more loops
                    cerr << "Got QuitKey, so exiting..." << endl;
                    p->doit=0;
                }
                else
                {
                    // send the keycode to the remote server
                    if (p->mmoved)
                    {
                        cout << "MotionNotify " << p->x << " " << p->y << endl;
                        p->mmoved=0;
                    }
                    cout << "KeyStrPress "
                         << XKeysymToString(XKeycodeToKeysym(p->LocalDpy,detail,0))
                         << endl;
                }

                break;

            case KeyRelease:
                // a key was released
                if (p->mmoved)
                {
                    cout << "MotionNotify " << p->x << " " << p->y << endl;
                    p->mmoved=0;
                }
                cout << "KeyStrRelease "
                     << XKeysymToString(XKeycodeToKeysym(p->LocalDpy,detail,0))
                     << endl;
                break;

        }//End of switch/case

        returning:
        //Commented this out and it still worksxxxxxxxxxxxxxxxxxxx
        XRecordFreeData(d);

        //TroubleshootingXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //Mouse data is still intact here
        /*cout << "just before eventCallback exit..." << endl
            << "event.x = " << event.get_x()
            << " event.y = " << event.get_y() << endl;*/

        ;

    }//End of eventCallBack

    //Static wrapper function
    void Tracker::callback(XPointer priv, XRecordInterceptData *d)
    {
        //Create pointer to callback
        Tracker *obj = (Tracker*) priv;

        //Assign callback pointer to C++ function
        obj -> eventCallback(priv, d);

    }

    /**************************************************************************
                                    EVENT LOOP
                                ======================
    Loops until quitkey is presed
    Sends all mouse and key eventd to the remote display
          \arg Display *LocalDPY - used display
          \arg int LocalScreen - used screen
          \arg Display *RecDpy - used display
          \arg unsigned int QuitKey - key that quits event loop
    ************************************************************************/
    void Tracker::eventLoop (Display *LocalDpy, int LocalScreen,
                    Display *RecDpy, unsigned int QuitKey)
    {

        Window Root, rRoot, rChild;
        XRecordContext rc;
        XRecordRange *rr;
        XRecordClientSpec rcs;
        Priv priv;
        int rootx, rooty, winx, winy;
        unsigned int mmask;
        Bool ret;
        Status sret;

        // get the root window and set default target
        Root = RootWindow ( LocalDpy, LocalScreen );

        ret=XQueryPointer(LocalDpy, Root, &rRoot, &rChild, &rootx, &rooty,
                        &winx, &winy, &mmask);
        cerr << "XQueryPointer returned: " << ret << endl;
        rr=XRecordAllocRange();

        if (!rr)
        {
            cerr << "Could not alloc record range, aborting." << endl;
            exit(EXIT_FAILURE);
        }

        rr->device_events.first=KeyPress;
        rr->device_events.last=MotionNotify;
        rcs=XRecordAllClients;
        rc=XRecordCreateContext(RecDpy, 0, &rcs, 1, &rr, 1);

        if (!rc)
        {
            cerr << "Could not create a record context, aborting." << endl;
            exit(EXIT_FAILURE);
        }

        priv.x=rootx;
        priv.y=rooty;
        priv.mmoved=1;
        priv.Status2=0;
        priv.Status1=2;
        priv.doit=1;
        priv.QuitKey=QuitKey;
        priv.LocalDpy=LocalDpy;
        priv.RecDpy=RecDpy;
        priv.rc=rc;

        //Assign callback
        if (!XRecordEnableContextAsync(RecDpy, rc, callback, (XPointer) &priv))
        {
            cerr << "Could not enable the record context, aborting." << endl;
            exit(EXIT_FAILURE);
        }

        while (priv.doit)
        {
            XRecordProcessReplies(RecDpy);
        }

        sret=XRecordDisableContext(LocalDpy, rc);
        if (!sret) cerr << "XRecordDisableContext failed!" << endl;
        sret=XRecordFreeContext(LocalDpy, rc);
        if (!sret) cerr << "XRecordFreeContext failed!" << endl;
        XFree(rr);

        //TroubleshootingXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //This mouse data is zero'd out for some reason!!!!!XXXXXX
        //Possibly an asynch issue with the callback function,
        //though putting a sleep function in the controller did not work.
        /*cout << "just before event loop exit..." << endl
            << "event.x = " << event.get_x()
            << " event.y = " << event.get_y() << endl;*/

    }//End of eventLoop


