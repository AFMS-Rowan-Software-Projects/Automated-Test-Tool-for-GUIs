//Class EventRepository stores mouse events

#include "EventRepository.h"
#include <vector>
#include <iostream>

using namespace std;


//Constructor
EventRepository::EventRepository()
{
    //Allocates space initially for <int> events
    //Initial space allocation prevents vector re-sizing.
    //Adjust reserve if typical use is too large/small.
    eventRepo.reserve (100);
}

//Destructor
EventRepository::~EventRepository()
{
    //dtor
}

//Adds mouse event to repository
void EventRepository::add (MouseEvent event)
{
    //Place event at end of vector
    eventRepo.push_back(event);

    //Purely test code for output to see add is working
    cout << endl << "this type event = " << event.to_string() << endl
         << "repo size = " << eventRepo.size() << endl;


    //display vector
    /*cout << "Vector contents: " << endl;
    for (int i : eventRepo)
    {
        cout << endl << "i = " << i << endl;
    }*/
}

//Returns size of repository
int EventRepository::size_of()
{
    return eventRepo.size();
}


//Returns entire repository contents
vector <MouseEvent> EventRepository::get_repository ()
{
    return eventRepo;
}
