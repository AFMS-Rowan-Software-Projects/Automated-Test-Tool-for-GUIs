//Class GUITestController provides controller functionality to GUI Test


#include "GUITestController.h"
#include "GUI.h"
#include "MouseEvent.h"
#include "Tracker.h"

using namespace std;


//Constructor
GUITestController::GUITestController()
{

}

/*GUITestController::GUITestController(Tracker &tracker)
{
    mouseTracker = tracker;
}*/

//Destructor
GUITestController::~GUITestController()
{
    //dtor
}

//Add mouse event to repository
void GUITestController::add (MouseEvent event)
{
    repository.add (event);
    cout << repository.size_of() << endl;
}

//Returns size of mouse event repository
int GUITestController::size_of_repo ()
{
    return repository.size_of();
}

//Select type of mouse event to record
void GUITestController::set_event_type(int eventType)
{
    recordEventType = eventType;
}


//Start and stop recording mouse event.
//Uses count from button clicks to determine start vs stop.
void GUITestController::record(int count)
{
    //static MouseEvent event;
    //static Tracker mouseTracker;

    cout << "recording..." << endl;

    //count is odd if recording starting, even if recording ending
    //Start recording
    if (count % 2 == 1)
    {
        //Start mouse recorder
        cout << "/n" << count << endl;

        mouseTracker.track_mouse();
        //Record gathered mouse dataXXXXXXXXXXXXXXXXXXXX
        //this isnt working!!!!!XXXXXXXXXXXXXXXXXXXXXXXXXXX
        //loses mouse data gathered in mouseTracker!!!!XXXXXXXXXXXXX
        //If event data is set manually here, data persists and gets added
        //to repo just fine.
        event.set_coord(mouseTracker.get_x(), mouseTracker.get_y());

        cout << endl << "after set_coord, mouseTracker.get_x = " << mouseTracker.get_x()
             << " mouseTracker.get_y = " << mouseTracker.get_y();

        //Troubleshooting codeXXXXXXXXXXXXXXXXXXXXxx
        cout << endl << "event from record if..." << endl
             << "event.x = " << event.get_x()
             << " event.y = " << event.get_y() << endl;


    }
    //Stop recording and record data
    else
    {
        cout << "/n" << count << endl;


        //Troubleshooting codeXXXXXXXXXXXXXXXXXXXXxx
        cout << endl << "event from stop record else..." << endl
             << "event.x = " << event.get_x()
             << " event.y = " << event.get_y() << endl;

        repository.add(event);
    }



}//End of record


