#ifndef GUI_H
#define GUI_H

#include "GUI.h"
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/TextF.h>
#include <Xm/Text.h>
#include <Xm/Label.h>
#include "GUITestController.h"
#include <iostream>

using namespace std;

class GUI
{
    public:
        //Constructor
        GUI(GUITestController &controller, int argc, char* argv[]);
        //Destructor
        virtual ~GUI();

        //Types of events to record
        enum buttonType {NONE, PUSHBUTTON, SCROLLBOX, TEXTBOX,
                    MENU, DROPBOX, RADIOBUTTON};


    private:

        GUITestController controller;

        int recordMode = NONE; //enum indicating current recording mode

        //Callback functions for each type of widget to be tested.
        //For each, a static "wrapper" function provided to
        //interface with Motif XtAddCallback function.
        //Wrapper calls subsequent function to provide callback
        //functionality.
        static void pushbutton_callback (Widget widget, XtPointer client_data, XtPointer call_data);
        void pushbutton_pushed (Widget widget, XtPointer client_data, XtPointer call_data);


        static void scrollbox_callback( Widget widget, XtPointer client_data, XtPointer call_data);
        void scrollbox_pushed (Widget widget, XtPointer client_data, XtPointer call_data);


        static void textbox_callback (Widget widget, XtPointer client_data, XtPointer call_data);
        void textbox_pushed(Widget widget, XtPointer client_data, XtPointer call_data);



        //Cycles color of widget to indicate recording/finished recording.
        void set_widget_color (Widget widget, int count);

};//End of Class GUI

#endif // GUI_H
