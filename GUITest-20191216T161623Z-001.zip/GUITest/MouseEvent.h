#ifndef MOUSEEVENT_H
#define MOUSEEVENT_H

#include <string>

using namespace std;

class MouseEvent
{
    public:
        MouseEvent();
        virtual ~MouseEvent();
        void set_press(string buttonPressed);
        string get_press();
        void set_release(string buttonReleased);
        string get_release();
        void set_coord(int x, int y);
        int get_x();
        int get_y();
        string to_string();

    protected:

    private:

        //Stores basic mouse event data
        struct EventData
        {
            int eventType;
            int x;
            int y;
            string buttonPressed;
            string buttonReleased;

        };

        EventData event;
};

#endif // MOUSEEVENT_H
