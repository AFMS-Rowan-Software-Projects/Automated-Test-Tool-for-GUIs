#ifndef EVENTREPOSITORY_H
#define EVENTREPOSITORY_H

#include <vector>
#include "MouseEvent.h"

using namespace std;

//Class EventRepository stores mouse events in vector
class EventRepository
{

    private:
        vector<MouseEvent> eventRepo;

    public:
        //Constructor
        EventRepository();
        //Destructor
        virtual ~EventRepository();

        //Getters/setters
        void add (MouseEvent event);

        //Returns size of repository
        int size_of();

        //Return entire event repository
        vector <MouseEvent> get_repository ();


};

#endif // EVENTREPOSITORY_H
