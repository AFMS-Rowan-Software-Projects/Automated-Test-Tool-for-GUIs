#include <iostream>
#include <gtest/gtest.h>
#include <gmock/gmock.h>

using namespace std;

// gmock and gtest 1.7 and higher require 2 variables
// being passed in through the sample
// test you will create
TEST(Test_Name, Subtest1)
{
  ASSERT_TRUE(1 == 2);
}

TEST(Test_Name, Subtest2)
{
  ASSERT_FALSE(1 == 2);
}

int main(int argc, char** argv) {

  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();

}

// The older versions of gtest and gmock
// require only a variable passed in.
//TEST_F(THIS_IS_A_TEST)
//{
  //  ASSERT_EQ(4, 2+2);
  //}
 
